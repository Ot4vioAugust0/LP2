﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício2 : Form
    {
        public frmExercício2()
        {
            InitializeComponent();
        }
        int numeroN;
        Double resultado=0;
        private void btnGerarNumero_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtNumeroN.Text, out numeroN) || (numeroN==0))
            {
                MessageBox.Show("Digite um Numero válido e que não seja 0");
                txtNumeroN.Focus();
                return;
            }
            
    
                for (int i = 1; i <= numeroN; i++)
                {
                    resultado += 1.0 / i;
                }
                txtNumeroH.Text = resultado.ToString("F2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumeroH.Clear();
            txtNumeroN.Clear();
        }
    }
            }
        
    

