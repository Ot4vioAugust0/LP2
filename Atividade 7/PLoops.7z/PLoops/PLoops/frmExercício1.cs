﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício1 : Form
    {
        public frmExercício1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int cont=0;

            foreach(char c in rchtxtFrase.Text)
            {
                if(char.IsWhiteSpace(c)) cont++;
            
            }
            MessageBox.Show("A quantidade de espaços em branco: " + cont); 
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int i=0, contaR=0;
            while (i<rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[i] =='R' || rchtxtFrase.Text[i] =='r')
                    { 
                    contaR++; 
                    }
                i++;
            
            }
            MessageBox.Show("Numero de R's: " + contaR);
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int contapar = 0;
            for(int i=0;i<rchtxtFrase.Text.Length-1;i++)
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i+1] && (rchtxtFrase.Text[i] != ' ' && rchtxtFrase.Text[i + 1] !=' '))
                    { 
                    contapar++; 
                    }

            }
            MessageBox.Show("Numero de pares: "+contapar);

        }
    }
}
