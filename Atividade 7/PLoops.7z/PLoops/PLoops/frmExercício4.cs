﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Entrada de dados dos TextBoxes
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int producao = 0;
            double salario = 0;
            double gratificacao = 0;

            // Validar e converter os valores de Produção, Salário e Gratificação
            if (!int.TryParse(txtProducao.Text, out producao) || producao < 0)
            {
                MessageBox.Show("Por favor, insira um valor válido para Produção.");
                return;
            }

            if (!double.TryParse(txtSalario.Text, out salario) || salario < 0)
            {
                MessageBox.Show("Por favor, insira um valor válido para Salário.");
                return;
            }

            if (!double.TryParse(txtGratificacao.Text, out gratificacao) || gratificacao < 0)
            {
                MessageBox.Show("Por favor, insira um valor válido para Gratificação.");
                return;
            }

            // Calcular os valores de B, C e D
            int B = (producao >= 100) ? 1 : 0;
            int C = (producao >= 120) ? 1 : 0;
            int D = (producao >= 150) ? 1 : 0;

            // Calcular o salário bruto inicial
            double salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            // Aplicar a restrição do salário máximo

            if (salarioBruto > 7000 && (producao < 150 || gratificacao == 0))
            {
                salarioBruto = 7000; // Limitar o salário bruto a 7000 se não atender às condições especiais
            }
            MessageBox.Show("Salário Bruto:" + salarioBruto);

        }
    }
}
