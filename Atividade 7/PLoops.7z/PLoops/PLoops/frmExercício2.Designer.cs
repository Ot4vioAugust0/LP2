﻿namespace PLoops
{
    partial class frmExercício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumeroN = new System.Windows.Forms.Label();
            this.txtNumeroN = new System.Windows.Forms.TextBox();
            this.btnGerarNumero = new System.Windows.Forms.Button();
            this.txtNumeroH = new System.Windows.Forms.TextBox();
            this.lblNumeroH = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNumeroN
            // 
            this.lblNumeroN.AutoSize = true;
            this.lblNumeroN.Location = new System.Drawing.Point(200, 81);
            this.lblNumeroN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumeroN.Name = "lblNumeroN";
            this.lblNumeroN.Size = new System.Drawing.Size(55, 13);
            this.lblNumeroN.TabIndex = 0;
            this.lblNumeroN.Text = "Numero N";
            // 
            // txtNumeroN
            // 
            this.txtNumeroN.Location = new System.Drawing.Point(267, 77);
            this.txtNumeroN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNumeroN.Name = "txtNumeroN";
            this.txtNumeroN.Size = new System.Drawing.Size(68, 20);
            this.txtNumeroN.TabIndex = 1;
            // 
            // btnGerarNumero
            // 
            this.btnGerarNumero.Location = new System.Drawing.Point(223, 155);
            this.btnGerarNumero.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGerarNumero.Name = "btnGerarNumero";
            this.btnGerarNumero.Size = new System.Drawing.Size(101, 40);
            this.btnGerarNumero.TabIndex = 2;
            this.btnGerarNumero.Text = "Gerar Numero H";
            this.btnGerarNumero.UseVisualStyleBackColor = true;
            this.btnGerarNumero.Click += new System.EventHandler(this.btnGerarNumero_Click);
            // 
            // txtNumeroH
            // 
            this.txtNumeroH.Location = new System.Drawing.Point(267, 111);
            this.txtNumeroH.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumeroH.Name = "txtNumeroH";
            this.txtNumeroH.Size = new System.Drawing.Size(68, 20);
            this.txtNumeroH.TabIndex = 3;
            // 
            // lblNumeroH
            // 
            this.lblNumeroH.AutoSize = true;
            this.lblNumeroH.Location = new System.Drawing.Point(200, 118);
            this.lblNumeroH.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumeroH.Name = "lblNumeroH";
            this.lblNumeroH.Size = new System.Drawing.Size(55, 13);
            this.lblNumeroH.TabIndex = 4;
            this.lblNumeroH.Text = "Numero H";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(363, 155);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(2);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(101, 40);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercício2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblNumeroH);
            this.Controls.Add(this.txtNumeroH);
            this.Controls.Add(this.btnGerarNumero);
            this.Controls.Add(this.txtNumeroN);
            this.Controls.Add(this.lblNumeroN);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercício2";
            this.Text = "frmExercício2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumeroN;
        private System.Windows.Forms.TextBox txtNumeroN;
        private System.Windows.Forms.Button btnGerarNumero;
        private System.Windows.Forms.TextBox txtNumeroH;
        private System.Windows.Forms.Label lblNumeroH;
        private System.Windows.Forms.Button btnLimpar;
    }
}