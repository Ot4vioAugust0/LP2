﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício1>().Count() > 0)
            {
                Application.OpenForms["frmExercício1"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                frmExercício1 obj1 = new frmExercício1(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício2>().Count() > 0)
            {
                Application.OpenForms["frmExercício2"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                frmExercício2 obj1 = new frmExercício2(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício3>().Count() > 0)
            {
                Application.OpenForms["frmExercício3"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                frmExercício3 obj1 = new frmExercício3(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício4>().Count() > 0)
            {
                Application.OpenForms["frmExercício4"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                frmExercício4 obj1 = new frmExercício4(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
