﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício3 : Form
    {
        public frmExercício3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string textoOriginal = txtPalindrimo.Text;
            string textoSemEspacos = "";

            
            for (int i = 0; i < textoOriginal.Length; i++)
            {
                if (textoOriginal[i] != ' ')
                {
                    textoSemEspacos += textoOriginal[i];
                }
            }

            
            textoSemEspacos = textoSemEspacos.ToLower();

            
            bool ehPalindromo = true;
            for (int i = 0; i < textoSemEspacos.Length / 2; i++)
            {
                if (textoSemEspacos[i] != textoSemEspacos[textoSemEspacos.Length - 1 - i])
                {
                    ehPalindromo = false;
                    break; 
                }
            }

            
            if (ehPalindromo)
            {
                MessageBox.Show("A frase é um palíndromo.");
            }
            else
            {
                MessageBox.Show("A frase não é um palíndromo.");
            }
        }
    }
}
