﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade
{
    public partial class Form1 : Form
    {
        private ArrayList alunos;

        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");

                if(auxiliar=="")
                {
                    break;
                }

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero invalido");
                    i--;
                }
                
            }
            Array.Reverse(vetor);

            //auxiliar = "";
            //foreach (int x in vetor)
            //{
              //  auxiliar += x + "\n";
            //}

            // ou 2a forma de criar a string de saida 
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);

            MessageBox.Show(auxiliar);


        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double [20,3];
            string auxiliar = "";
            double media = 0;
            string saida = "";

            for(int i = 0;i < 2;i++)
            {
                media = 0;
                for(int j = 0;j < 3;j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j+1} nota do aluno {i+1}", 
                        "Entrada de dados");

                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0
                        || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota Inválida!");
                        j--;
                    }
                    else
                        {
                        media += notas[i, j];
                        }
                }
                media = media / 3;
                saida += $"Aluno{i + 1}: média:{media.ToString("N2")}\n";
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obejeto4 = new frmExercicio4();
            obejeto4.Show();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            List<string> nomes = new List<string> { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio",
"Marcelo", "Pedro", "Thais" };

            nomes.Remove("Otávio");

            string mensagem = "Nomes restantes:\n";
            foreach (string nome in nomes)
            {
                mensagem += nome + "\n";
            }

            MessageBox.Show(mensagem, "Nomes");


        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frm5 obejeto5 = new frm5();
            obejeto5.Show();
        }
    }
}
