﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade
{
    public partial class frm5 : Form
    {
        public frm5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int ultimoDigRa = 7;
            if (ultimoDigRa == 0 )
            {
                ultimoDigRa = 2;
            }

            char[] respostas = { 'A', 'B', 'C', 'E', 'D', 'A', 'B', 'B', 'D', 'D' };
            char[,] respostaAlns = new char[ultimoDigRa, 10];
            
            lstbxResposta.Items.Clear();

            for (int aluno = 0; aluno < ultimoDigRa; aluno++)
            {
                for (int questoes = 0; questoes < 10; questoes++)
                {
                    string auxiliar;
                    auxiliar = Interaction.InputBox($"Digite a resposta do aluno {aluno + 1} na questão {questoes + 1}: ", "Entrada de Dados");


                    if (auxiliar.Length == 1 && "ABCDE".Contains(auxiliar))
                    {
                        char resposta = auxiliar[0];
                        respostaAlns[aluno, questoes] = resposta;

                        if (respostaAlns[aluno, questoes] == respostas[questoes])
                        {
                            lstbxResposta.Items.Add($"O aluno {aluno + 1} acertou a questão {questoes + 1}. Era {respostas[questoes]}, e foi colocado {respostaAlns[aluno, questoes]}");

                        }
                        else
                        {
                            lstbxResposta.Items.Add($"O aluno {aluno + 1} errou a questão {questoes + 1}. Era {respostas[questoes]}, e foi colocado {respostaAlns[aluno, questoes]}");

                        }


                    }
                    else
                    {
                        MessageBox.Show("Deve ser apenas 1 caracter, contendo as seguintes letras: *A B C D E*");
                        questoes--; 

                    }
                }
            }
        }
    }
}
