﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] filmes = new double[2, 2];
            string auxiliar = "";
            double[] media = new double[2];
            

            for (int i = 0; i < 2; i++)
            {
                
                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota filme {j + 1} da pessoa{i + 1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out filmes[i, j]) || filmes[i, j] < 0
                        || filmes[i, j] > 10)
                    {
                        MessageBox.Show("Nota Inválida!");
                        j--;
                    }
                    else
                    {

                        media[j] += filmes[i, j];
                        lstbxFilme.Items.Add($"Pessoa {i + 1}: Nota do Filme {j+1}: {filmes[i,j]}\n");
                    }
                }

                
            }
            for (int i = 0; i < 2; i++)
            {
                media[i] = media[i] / 2;
                lstbxFilme.Items.Add($"Media do Filme {i + 1}: {media[i].ToString("N2")}");
            }

            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //lstbxFilme.Clear();
        }
    }
}
