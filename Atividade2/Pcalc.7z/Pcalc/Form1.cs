﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Número invalido");
                txtNum2.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("numero 2 não pode ser 0!");
                txtNum2.Focus();
            }
            else
            {
                resultado = (numero1 / numero2);
                txtResult.Text = resultado.ToString();
            }
            }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear(); 
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
           if(!double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("Número inválido");
                txtNum1.Focus();
            }
        }
    }
}
