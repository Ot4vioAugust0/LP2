﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnNumeros = new System.Windows.Forms.Button();
            this.btnEspBranco = new System.Windows.Forms.Button();
            this.btnContLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(49, 32);
            this.rchtxtTexto.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(297, 234);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnNumeros
            // 
            this.btnNumeros.Location = new System.Drawing.Point(372, 32);
            this.btnNumeros.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnNumeros.Name = "btnNumeros";
            this.btnNumeros.Size = new System.Drawing.Size(191, 63);
            this.btnNumeros.TabIndex = 1;
            this.btnNumeros.Text = "Contar quantidade de Numeros";
            this.btnNumeros.UseVisualStyleBackColor = true;
            this.btnNumeros.Click += new System.EventHandler(this.btnNumeros_Click);
            // 
            // btnEspBranco
            // 
            this.btnEspBranco.Location = new System.Drawing.Point(372, 116);
            this.btnEspBranco.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnEspBranco.Name = "btnEspBranco";
            this.btnEspBranco.Size = new System.Drawing.Size(191, 63);
            this.btnEspBranco.TabIndex = 2;
            this.btnEspBranco.Text = "Posição do 1° espaço em braco";
            this.btnEspBranco.UseVisualStyleBackColor = true;
            this.btnEspBranco.Click += new System.EventHandler(this.btnEspBranco_Click);
            // 
            // btnContLetras
            // 
            this.btnContLetras.Location = new System.Drawing.Point(372, 203);
            this.btnContLetras.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnContLetras.Name = "btnContLetras";
            this.btnContLetras.Size = new System.Drawing.Size(191, 63);
            this.btnContLetras.TabIndex = 3;
            this.btnContLetras.Text = "Contar quantidade de letras";
            this.btnContLetras.UseVisualStyleBackColor = true;
            this.btnContLetras.Click += new System.EventHandler(this.btnContLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 749);
            this.Controls.Add(this.btnContLetras);
            this.Controls.Add(this.btnEspBranco);
            this.Controls.Add(this.btnNumeros);
            this.Controls.Add(this.rchtxtTexto);
            this.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnNumeros;
        private System.Windows.Forms.Button btnEspBranco;
        private System.Windows.Forms.Button btnContLetras;
    }
}