﻿namespace Ptriangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValA = new System.Windows.Forms.Label();
            this.lblValB = new System.Windows.Forms.Label();
            this.lblValC = new System.Windows.Forms.Label();
            this.txtValA = new System.Windows.Forms.TextBox();
            this.txtValC = new System.Windows.Forms.TextBox();
            this.txtValB = new System.Windows.Forms.TextBox();
            this.btnExecuta = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btbLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValA
            // 
            this.lblValA.AutoSize = true;
            this.lblValA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValA.Location = new System.Drawing.Point(80, 40);
            this.lblValA.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValA.Name = "lblValA";
            this.lblValA.Size = new System.Drawing.Size(74, 17);
            this.lblValA.TabIndex = 0;
            this.lblValA.Text = "Valor de A";
            // 
            // lblValB
            // 
            this.lblValB.AutoSize = true;
            this.lblValB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValB.Location = new System.Drawing.Point(80, 75);
            this.lblValB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValB.Name = "lblValB";
            this.lblValB.Size = new System.Drawing.Size(74, 17);
            this.lblValB.TabIndex = 1;
            this.lblValB.Text = "Valor de B";
            // 
            // lblValC
            // 
            this.lblValC.AutoSize = true;
            this.lblValC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValC.Location = new System.Drawing.Point(80, 108);
            this.lblValC.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValC.Name = "lblValC";
            this.lblValC.Size = new System.Drawing.Size(74, 17);
            this.lblValC.TabIndex = 2;
            this.lblValC.Text = "Valor de C";
            // 
            // txtValA
            // 
            this.txtValA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValA.Location = new System.Drawing.Point(181, 40);
            this.txtValA.Margin = new System.Windows.Forms.Padding(2);
            this.txtValA.Name = "txtValA";
            this.txtValA.Size = new System.Drawing.Size(68, 23);
            this.txtValA.TabIndex = 3;
            this.txtValA.Validated += new System.EventHandler(this.txtValA_Validated);
            // 
            // txtValC
            // 
            this.txtValC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValC.Location = new System.Drawing.Point(181, 110);
            this.txtValC.Margin = new System.Windows.Forms.Padding(2);
            this.txtValC.Name = "txtValC";
            this.txtValC.Size = new System.Drawing.Size(68, 23);
            this.txtValC.TabIndex = 4;
            this.txtValC.Validated += new System.EventHandler(this.txtValC_Validated);
            // 
            // txtValB
            // 
            this.txtValB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValB.Location = new System.Drawing.Point(181, 75);
            this.txtValB.Margin = new System.Windows.Forms.Padding(2);
            this.txtValB.Name = "txtValB";
            this.txtValB.Size = new System.Drawing.Size(68, 23);
            this.txtValB.TabIndex = 5;
            this.txtValB.Validated += new System.EventHandler(this.txtValB_Validated);
            // 
            // btnExecuta
            // 
            this.btnExecuta.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnExecuta.Location = new System.Drawing.Point(283, 53);
            this.btnExecuta.Margin = new System.Windows.Forms.Padding(2);
            this.btnExecuta.Name = "btnExecuta";
            this.btnExecuta.Size = new System.Drawing.Size(77, 27);
            this.btnExecuta.TabIndex = 6;
            this.btnExecuta.Text = "Executar";
            this.btnExecuta.UseVisualStyleBackColor = false;
            this.btnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSair.Location = new System.Drawing.Point(181, 159);
            this.btnSair.Margin = new System.Windows.Forms.Padding(2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(77, 27);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btbLimpar
            // 
            this.btbLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btbLimpar.Location = new System.Drawing.Point(283, 85);
            this.btbLimpar.Name = "btbLimpar";
            this.btbLimpar.Size = new System.Drawing.Size(80, 26);
            this.btbLimpar.TabIndex = 9;
            this.btbLimpar.Text = "Limpar";
            this.btbLimpar.UseVisualStyleBackColor = false;
            this.btbLimpar.Click += new System.EventHandler(this.btbLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 234);
            this.Controls.Add(this.btbLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExecuta);
            this.Controls.Add(this.txtValB);
            this.Controls.Add(this.txtValC);
            this.Controls.Add(this.txtValA);
            this.Controls.Add(this.lblValC);
            this.Controls.Add(this.lblValB);
            this.Controls.Add(this.lblValA);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValA;
        private System.Windows.Forms.Label lblValB;
        private System.Windows.Forms.Label lblValC;
        private System.Windows.Forms.TextBox txtValA;
        private System.Windows.Forms.TextBox txtValC;
        private System.Windows.Forms.TextBox txtValB;
        private System.Windows.Forms.Button btnExecuta;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btbLimpar;
    }
}

