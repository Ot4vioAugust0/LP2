﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulos
{
    public partial class Form1 : Form
    {
        double valA, valB, valC;

        private void txtValB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValB.Text, out valB) || valB ==0)
            {
                MessageBox.Show("Valor Inválido!");
                txtValB.Focus();
            }
        }

        private void txtValC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValC.Text, out valC) || valC == 0)
            {
                MessageBox.Show("Valor Inválido!");
                txtValC.Focus();    
            }


        }

        private void btbLimpar_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();    
            txtValC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (valA + valB > valC && valA + valC > valB && valB + valC > valA)
            {
                if (valA == valB && valB == valC)
                {
                    MessageBox.Show("Triangulo Equilátero");
                }
                else if (valA == valB || valA == valC || valB == valC)
                {
                    MessageBox.Show("Triângulo Isóceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os valores não formam um triângulo!");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValA.Text, out valA) || valA == 0)
            {
                MessageBox.Show("Valor Inválido!");
                txtValA.Focus();
            }
        }
    }
}
